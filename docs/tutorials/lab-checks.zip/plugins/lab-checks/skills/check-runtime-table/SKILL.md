---
name: check-runtime-table
description: Use when checking a runtime CSV before comparing configurations. Triggers on "check this runtime table". Not for changing data or plotting it.
---

# Check a runtime table

Read the requested CSV with the Pandas MCP's live tools. Check that configuration,
trial and runtime_s exist. Runtime units must be supplied by the user; ask if unknown.
Check missing values, row count and numeric ranges before drawing conclusions.
Report whether a profile covered every row or only a sample. Do not modify inputs.
Use groupby_operations for mean runtime_s by configuration and retain its returned
output_file. Check one mean independently from the tiny supplied input; for a large
input, explain what additional verification is needed instead of loading it all.
Write runtime-check.md with the source, coverage, missing-value policy, group means,
units and output path. Do not infer a performance improvement or cause from a small
fixture. Stop and explain if a required MCP or column is missing.
