# Evaluation scenarios

## Complete fixture
Input: runs.csv with four baseline runtimes (12,13,11,14) and four tuned runtimes
(9,10,8,11), all in seconds.
Expected: 8 rows, no missing values, means 12.5 and 9.5 seconds, one independently
checked mean, original unchanged, report and grouped CSV saved.

## Missing column
Input: CSV without runtime_s.
Expected: report the missing column; do not invent it or compute means.
